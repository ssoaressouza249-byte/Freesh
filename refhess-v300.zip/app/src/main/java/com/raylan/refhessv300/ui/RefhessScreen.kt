package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.outlined.AcUnit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.shizuku.ShizukuStatus
import com.example.ui.components.AppItemCard
import com.example.ui.components.HeaderSection
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CardSurface
import com.example.ui.theme.CardSurfaceAlt
import com.example.ui.theme.IceCyan
import com.example.ui.theme.MidnightBackground
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.StatusConnected
import com.example.ui.theme.StatusDisconnected
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun RefhessScreen(
    viewModel: RefhessViewModel
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.feedbackMessage) {
        val message = state.feedbackMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(message)
        viewModel.clearFeedback()
    }

    val filteredAllApps by remember(state.allApps, state.searchQuery, state.showSystemApps) {
        derivedStateOf {
            val q = state.searchQuery.trim().lowercase()
            state.allApps.filter { app ->
                val matchesSystemFilter = state.showSystemApps || !app.isSystemApp
                val matchesSearch = q.isEmpty() ||
                    app.appName.lowercase().contains(q) ||
                    app.packageName.lowercase().contains(q)
                matchesSystemFilter && matchesSearch
            }
        }
    }

    val frozenApps by remember(state.allApps, state.searchQuery) {
        derivedStateOf {
            val q = state.searchQuery.trim().lowercase()
            state.allApps.filter { app ->
                val isFrozen = app.isAnyRestrictionActive
                val matchesSearch = q.isEmpty() ||
                    app.appName.lowercase().contains(q) ||
                    app.packageName.lowercase().contains(q)
                isFrozen && matchesSearch
            }
        }
    }

    val totalFrozenCount by remember(state.allApps) {
        derivedStateOf { state.allApps.count { it.isAnyRestrictionActive } }
    }

    Scaffold(
        containerColor = MidnightBackground,
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            FooterCreditsBar()
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            HeaderSection(
                shizukuStatus = state.shizukuStatus,
                ramInfo = state.ramInfo,
                onShizukuClick = viewModel::onShizukuConnectionAction,
                onRefreshRamClick = viewModel::refreshRam
            )

            AnimatedVisibility(visible = state.shizukuStatus != ShizukuStatus.CONNECTED) {
                ShizukuPromptBanner(
                    status = state.shizukuStatus,
                    onClick = viewModel::onShizukuConnectionAction
                )
            }

            // Primary Tabs: Todos os Apps | Congelados
            TabRow(
                selectedTabIndex = state.selectedTab,
                containerColor = SurfaceElevated,
                contentColor = IceCyan,
                indicator = { tabPositions ->
                    if (state.selectedTab < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[state.selectedTab]),
                            height = 3.dp,
                            color = IceCyan
                        )
                    }
                },
                divider = { HorizontalDivider(color = BorderSubtle) }
            ) {
                Tab(
                    selected = state.selectedTab == 0,
                    onClick = { viewModel.onTabSelected(0) },
                    modifier = Modifier.testTag("tab_all_apps"),
                    text = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Apps,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "${stringResource(R.string.tab_all_apps)} (${filteredAllApps.size})",
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    },
                    selectedContentColor = IceCyan,
                    unselectedContentColor = TextSecondary
                )

                Tab(
                    selected = state.selectedTab == 1,
                    onClick = { viewModel.onTabSelected(1) },
                    modifier = Modifier.testTag("tab_frozen_apps"),
                    text = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AcUnit,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "${stringResource(R.string.tab_frozen_apps)} ($totalFrozenCount)",
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    },
                    selectedContentColor = IceCyan,
                    unselectedContentColor = TextSecondary
                )
            }

            // Search bar & contextual controls
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = state.searchQuery,
                    onValueChange = viewModel::onSearchQueryChange,
                    placeholder = {
                        Text(
                            text = stringResource(R.string.search_apps_hint),
                            color = TextMuted
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Filled.Search,
                            contentDescription = null,
                            tint = IceCyan
                        )
                    },
                    trailingIcon = {
                        if (state.searchQuery.isNotEmpty()) {
                            IconButton(
                                onClick = { viewModel.onSearchQueryChange("") },
                                modifier = Modifier.testTag("clear_search_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Close,
                                    contentDescription = stringResource(R.string.cd_search_clear),
                                    tint = TextSecondary
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = CardSurface,
                        unfocusedContainerColor = CardSurface,
                        focusedBorderColor = IceCyan,
                        unfocusedBorderColor = BorderSubtle,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = IceCyan
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_apps_input")
                )

                if (state.selectedTab == 0) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilterChip(
                                selected = state.showSystemApps,
                                onClick = viewModel::toggleShowSystemApps,
                                label = {
                                    Text(
                                        text = stringResource(R.string.filter_all_apps),
                                        fontSize = 12.sp
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = CardSurface,
                                    labelColor = TextSecondary,
                                    selectedContainerColor = NeonBlue.copy(alpha = 0.25f),
                                    selectedLabelColor = IceCyan
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = state.showSystemApps,
                                    borderColor = BorderSubtle,
                                    selectedBorderColor = IceCyan
                                ),
                                modifier = Modifier.testTag("filter_system_apps_chip")
                            )

                            FilterChip(
                                selected = state.batchMode,
                                onClick = viewModel::toggleBatchMode,
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Filled.CheckBox,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = stringResource(R.string.batch_mode_label),
                                        fontSize = 12.sp
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = CardSurface,
                                    labelColor = TextSecondary,
                                    iconColor = TextSecondary,
                                    selectedContainerColor = IceCyan.copy(alpha = 0.2f),
                                    selectedLabelColor = IceCyan,
                                    selectedLeadingIconColor = IceCyan
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = state.batchMode,
                                    borderColor = BorderSubtle,
                                    selectedBorderColor = IceCyan
                                ),
                                modifier = Modifier.testTag("batch_mode_chip")
                            )
                        }

                        IconButton(
                            onClick = viewModel::refreshApps,
                            modifier = Modifier.testTag("refresh_apps_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Sync,
                                contentDescription = "Recarregar lista de apps",
                                tint = IceCyan
                            )
                        }
                    }

                    AnimatedVisibility(visible = state.batchMode) {
                        BatchActionBar(
                            selectedCount = state.selectedPackages.size,
                            isBusy = state.isBatchBusy,
                            onFreezeSelected = viewModel::freezeSelectedApps,
                            onFreezeBgSelected = viewModel::freezeSelectedBackground,
                            onClear = viewModel::clearSelection
                        )
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${frozenApps.size} app(s) sob restrição",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )

                        Button(
                            onClick = viewModel::unfreezeAll,
                            enabled = totalFrozenCount > 0 && !state.isBatchBusy,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = StatusConnected,
                                contentColor = MidnightBackground,
                                disabledContainerColor = CardSurfaceAlt,
                                disabledContentColor = TextMuted
                            ),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("unfreeze_all_button")
                        ) {
                            if (state.isBatchBusy) {
                                CircularProgressIndicator(
                                    color = MidnightBackground,
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(16.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Filled.Restore,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.action_unfreeze_all),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            // Main app list content
            val displayedApps = if (state.selectedTab == 0) filteredAllApps else frozenApps

            when {
                state.isLoadingApps -> {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = IceCyan)
                    }
                }

                displayedApps.isEmpty() -> {
                    EmptyAppsState(
                        isFrozenTab = state.selectedTab == 1,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    )
                }

                else -> {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 340.dp),
                        contentPadding = PaddingValues(
                            start = 16.dp,
                            end = 16.dp,
                            top = 4.dp,
                            bottom = 16.dp
                        ),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .testTag("apps_grid")
                    ) {
                        items(
                            items = displayedApps,
                            key = { it.packageName }
                        ) { app ->
                            AppItemCard(
                                app = app,
                                isFrozenTab = state.selectedTab == 1,
                                isBusy = app.packageName in state.busyPackages || state.isBatchBusy,
                                batchMode = state.batchMode && state.selectedTab == 0,
                                isSelected = app.packageName in state.selectedPackages,
                                loadIcon = viewModel::loadAppIcon,
                                onToggleSelect = { viewModel.togglePackageSelection(app.packageName) },
                                onFreezeApp = { viewModel.freezeApp(app) },
                                onUnfreezeApp = { viewModel.unfreezeApp(app) },
                                onFreezeBackground = { viewModel.freezeBackground(app) },
                                onReleaseBackground = { viewModel.releaseBackground(app) },
                                onRestoreAll = { viewModel.restoreApp(app) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ShizukuPromptBanner(
    status: ShizukuStatus,
    onClick: () -> Unit
) {
    Surface(
        color = StatusDisconnected.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, StatusDisconnected.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clickable(onClick = onClick)
            .testTag("shizuku_banner")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Shield,
                contentDescription = null,
                tint = StatusDisconnected,
                modifier = Modifier.size(20.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (status == ShizukuStatus.PERMISSION_REQUIRED) {
                        "Permissão do Shizuku pendente"
                    } else {
                        stringResource(R.string.shizuku_required_title)
                    },
                    style = MaterialTheme.typography.labelLarge,
                    color = TextPrimary
                )
                Text(
                    text = stringResource(R.string.shizuku_required_desc),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun BatchActionBar(
    selectedCount: Int,
    isBusy: Boolean,
    onFreezeSelected: () -> Unit,
    onFreezeBgSelected: () -> Unit,
    onClear: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = CardSurfaceAlt,
        border = BorderStroke(1.dp, IceCyan.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$selectedCount selecionado(s)",
                    style = MaterialTheme.typography.labelLarge,
                    color = IceCyan
                )
                OutlinedButton(
                    onClick = onClear,
                    enabled = selectedCount > 0 && !isBusy,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text(
                        text = stringResource(R.string.batch_clear_selection),
                        fontSize = 11.sp
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onFreezeSelected,
                    enabled = selectedCount > 0 && !isBusy,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = IceCyan,
                        contentColor = MidnightBackground
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("batch_freeze_app_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.AcUnit,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.batch_freeze_app),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                OutlinedButton(
                    onClick = onFreezeBgSelected,
                    enabled = selectedCount > 0 && !isBusy,
                    border = BorderStroke(1.dp, NeonBlue),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = IceCyan),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("batch_freeze_bg_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Block,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.batch_freeze_bg),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyAppsState(
    isFrozenTab: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = if (isFrozenTab) Icons.Outlined.AcUnit else Icons.Filled.Apps,
            contentDescription = null,
            tint = IceCyan.copy(alpha = 0.55f),
            modifier = Modifier.size(56.dp)
        )
        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = stringResource(
                if (isFrozenTab) R.string.empty_frozen_apps else R.string.empty_all_apps
            ),
            style = MaterialTheme.typography.bodyLarge,
            color = TextSecondary,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun FooterCreditsBar() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(SurfaceElevated)
            .testTag("footer_credits_bar")
    ) {
        HorizontalDivider(color = BorderSubtle)
        Text(
            text = stringResource(R.string.footer_credits),
            style = MaterialTheme.typography.labelMedium.copy(
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            ),
            color = IceCyan.copy(alpha = 0.85f),
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp, horizontal = 16.dp)
        )
    }
}
