package com.example.data

data class ManagedApp(
    val packageName: String,
    val appName: String,
    val isSystemApp: Boolean,
    val isAppFrozen: Boolean,
    val isBackgroundFrozen: Boolean,
    val versionName: String? = null
) {
    val isAnyRestrictionActive: Boolean
        get() = isAppFrozen || isBackgroundFrozen
}

data class RamInfo(
    val totalBytes: Long = 0L,
    val availableBytes: Long = 0L,
    val usedBytes: Long = 0L,
    val usedFraction: Float = 0f,
    val isLowMemory: Boolean = false
)
