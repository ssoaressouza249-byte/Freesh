package com.example.shizuku

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuRemoteProcess
import java.io.BufferedReader
import java.io.InputStreamReader
import java.lang.reflect.Method

enum class ShizukuStatus {
    CONNECTED,
    PERMISSION_REQUIRED,
    NOT_RUNNING
}

data class ShellResult(
    val exitCode: Int,
    val stdout: String,
    val stderr: String,
    val success: Boolean
)

class ShizukuEngine {

    private val _status = MutableStateFlow(ShizukuStatus.NOT_RUNNING)
    val status: StateFlow<ShizukuStatus> = _status.asStateFlow()

    private val packageRegex = Regex("^[a-zA-Z0-9._]+$")

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        _status.value = ShizukuStatus.NOT_RUNNING
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_PERMISSION_REQUEST_CODE) {
                refreshStatus()
            } else if (grantResult == PackageManager.PERMISSION_GRANTED) {
                refreshStatus()
            }
        }

    private var listenersRegistered = false

    @Volatile
    private var cachedNewProcessMethod: Method? = null

    fun registerListeners() {
        if (listenersRegistered) {
            refreshStatus()
            return
        }
        runCatching {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionResultListener)
            listenersRegistered = true
        }
        refreshStatus()
    }

    fun unregisterListeners() {
        if (!listenersRegistered) return
        runCatching {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(permissionResultListener)
            listenersRegistered = false
        }
    }

    fun refreshStatus(): ShizukuStatus {
        val alive = isBinderAlive()
        val nextStatus = when {
            !alive -> ShizukuStatus.NOT_RUNNING
            hasPermission() -> ShizukuStatus.CONNECTED
            else -> ShizukuStatus.PERMISSION_REQUIRED
        }
        _status.value = nextStatus
        return nextStatus
    }

    fun isBinderAlive(): Boolean {
        return runCatching { Shizuku.pingBinder() }.getOrDefault(false)
    }

    fun hasPermission(): Boolean {
        return runCatching {
            if (!Shizuku.pingBinder()) return@runCatching false
            if (Shizuku.isPreV11()) return@runCatching false
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
    }

    fun requestPermission(): Boolean {
        return runCatching {
            if (!Shizuku.pingBinder()) return@runCatching false
            if (Shizuku.isPreV11()) return@runCatching false
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                refreshStatus()
                return@runCatching true
            }
            Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
            true
        }.getOrDefault(false)
    }

    fun openShizukuManager(context: Context): Boolean {
        return runCatching {
            val intent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_MANAGER_PACKAGE)
                ?: return@runCatching false
            intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        }.getOrDefault(false)
    }

    suspend fun executeShell(command: String): ShellResult = withContext(Dispatchers.IO) {
        if (!isBinderAlive() || !hasPermission()) {
            return@withContext ShellResult(
                exitCode = -1,
                stdout = "",
                stderr = "Shizuku não conectado ou sem permissão.",
                success = false
            )
        }

        var process: ShizukuRemoteProcess? = null
        try {
            val proc = createShizukuProcess(command)
            process = proc
            if (proc == null) {
                return@withContext ShellResult(
                    exitCode = -1,
                    stdout = "",
                    stderr = "Falha ao iniciar processo remoto Shizuku.",
                    success = false
                )
            }

            val (stdout, stderr) = coroutineScope {
                val outDeferred = async(Dispatchers.IO) {
                    runCatching {
                        BufferedReader(InputStreamReader(proc.inputStream)).use { it.readText() }
                    }.getOrDefault("")
                }
                val errDeferred = async(Dispatchers.IO) {
                    runCatching {
                        BufferedReader(InputStreamReader(proc.errorStream)).use { it.readText() }
                    }.getOrDefault("")
                }
                outDeferred.await() to errDeferred.await()
            }

            val exitCode = runCatching { proc.waitFor() }.getOrDefault(-1)
            ShellResult(
                exitCode = exitCode,
                stdout = stdout.trim(),
                stderr = stderr.trim(),
                success = exitCode == 0
            )
        } catch (t: Throwable) {
            ShellResult(
                exitCode = -1,
                stdout = "",
                stderr = t.message ?: "Erro desconhecido ao executar comando Shizuku.",
                success = false
            )
        } finally {
            runCatching { process?.destroy() }
        }
    }

    private fun createShizukuProcess(command: String): ShizukuRemoteProcess? {
        return runCatching {
            val method = cachedNewProcessMethod ?: Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            ).apply {
                isAccessible = true
                cachedNewProcessMethod = this
            }
            method.invoke(
                null,
                arrayOf("sh", "-c", command),
                null,
                null
            ) as? ShizukuRemoteProcess
        }.getOrNull()
    }

    suspend fun freezeApp(packageName: String): ShellResult {
        if (!packageRegex.matches(packageName)) {
            return ShellResult(-1, "", "Pacote inválido: $packageName", false)
        }
        val cmd = "am force-stop $packageName && pm disable-user --user 0 $packageName"
        return executeShell(cmd)
    }

    suspend fun unfreezeApp(packageName: String): ShellResult {
        if (!packageRegex.matches(packageName)) {
            return ShellResult(-1, "", "Pacote inválido: $packageName", false)
        }
        val cmd = "pm enable $packageName"
        return executeShell(cmd)
    }

    suspend fun freezeBackground(packageName: String): ShellResult {
        if (!packageRegex.matches(packageName)) {
            return ShellResult(-1, "", "Pacote inválido: $packageName", false)
        }
        val cmd = buildString {
            append("cmd appops set $packageName RUN_IN_BACKGROUND ignore")
            append(" && (cmd appops set $packageName RUN_ANY_IN_BACKGROUND ignore 2>/dev/null || true)")
            append(" && (am set-inactive $packageName true 2>/dev/null || true)")
            append(" && am force-stop $packageName")
        }
        return executeShell(cmd)
    }

    suspend fun releaseBackground(packageName: String): ShellResult {
        if (!packageRegex.matches(packageName)) {
            return ShellResult(-1, "", "Pacote inválido: $packageName", false)
        }
        val cmd = buildString {
            append("cmd appops set $packageName RUN_IN_BACKGROUND allow")
            append(" && (cmd appops set $packageName RUN_ANY_IN_BACKGROUND allow 2>/dev/null || true)")
            append(" && (am set-inactive $packageName false 2>/dev/null || true)")
        }
        return executeShell(cmd)
    }

    suspend fun queryDisabledPackages(): Set<String> {
        if (!isBinderAlive() || !hasPermission()) return emptySet()
        val result = executeShell("pm list packages -d --user 0 2>/dev/null || pm list packages -d")
        if (!result.success && result.stdout.isEmpty()) return emptySet()
        return parsePackageListOutput(result.stdout)
    }

    suspend fun queryBackgroundRestrictedPackages(): Set<String> {
        if (!isBinderAlive() || !hasPermission()) return emptySet()
        val cmd = buildString {
            append("(cmd appops query-op --user 0 RUN_IN_BACKGROUND ignore 2>/dev/null || ")
            append("cmd appops query-op RUN_IN_BACKGROUND ignore 2>/dev/null || true); ")
            append("(cmd appops query-op --user 0 RUN_ANY_IN_BACKGROUND ignore 2>/dev/null || ")
            append("cmd appops query-op RUN_ANY_IN_BACKGROUND ignore 2>/dev/null || true)")
        }
        val result = executeShell(cmd)
        if (result.stdout.isBlank()) return emptySet()
        return result.stdout
            .lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.contains(" ") && packageRegex.matches(it) }
            .toSet()
    }

    private fun parsePackageListOutput(output: String): Set<String> {
        return output
            .lineSequence()
            .map { it.trim() }
            .filter { it.startsWith("package:") }
            .map { it.removePrefix("package:").trim() }
            .filter { packageRegex.matches(it) }
            .toSet()
    }

    companion object {
        const val SHIZUKU_PERMISSION_REQUEST_CODE = 3001
        const val SHIZUKU_MANAGER_PACKAGE = "moe.shizuku.privileged.api"
    }
}
