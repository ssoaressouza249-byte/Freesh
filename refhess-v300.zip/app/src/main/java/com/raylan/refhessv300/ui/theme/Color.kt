package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MidnightBackground = Color(0xFF080C14)
val SurfaceElevated = Color(0xFF0D1422)
val CardSurface = Color(0xFF111827)
val CardSurfaceAlt = Color(0xFF162033)
val BorderSubtle = Color(0xFF1E293B)

val IceCyan = Color(0xFF00E5FF)
val IceCyanDim = Color(0xFF00ACC1)
val NeonBlue = Color(0xFF2979FF)
val NeonBlueDeep = Color(0xFF1565C0)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val StatusConnected = Color(0xFF00E676)
val StatusDisconnected = Color(0xFFFF3D57)
val StatusWarning = Color(0xFFFFB300)
val SecurityTamperRed = Color(0xFFB71C1C)
