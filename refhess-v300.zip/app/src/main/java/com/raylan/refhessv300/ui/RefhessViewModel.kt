package com.example.ui

import android.app.Application
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppRepository
import com.example.data.ManagedApp
import com.example.data.RamInfo
import com.example.shizuku.ShizukuEngine
import com.example.shizuku.ShizukuStatus
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class RefhessUiState(
    val shizukuStatus: ShizukuStatus = ShizukuStatus.NOT_RUNNING,
    val ramInfo: RamInfo = RamInfo(),
    val allApps: List<ManagedApp> = emptyList(),
    val isLoadingApps: Boolean = true,
    val searchQuery: String = "",
    val showSystemApps: Boolean = false,
    val selectedTab: Int = 0,
    val batchMode: Boolean = false,
    val selectedPackages: Set<String> = emptySet(),
    val busyPackages: Set<String> = emptySet(),
    val isBatchBusy: Boolean = false,
    val feedbackMessage: String? = null
)

class RefhessViewModel(application: Application) : AndroidViewModel(application) {

    private val shizukuEngine = ShizukuEngine()
    private val repository = AppRepository(application.applicationContext, shizukuEngine)

    private val _uiState = MutableStateFlow(RefhessUiState())
    val uiState: StateFlow<RefhessUiState> = _uiState.asStateFlow()

    init {
        shizukuEngine.registerListeners()

        viewModelScope.launch {
            shizukuEngine.status.collect { status ->
                val previous = _uiState.value.shizukuStatus
                _uiState.update { it.copy(shizukuStatus = status) }
                if (status == ShizukuStatus.CONNECTED && previous != ShizukuStatus.CONNECTED) {
                    refreshApps()
                }
            }
        }

        refreshRam()
        refreshApps()

        viewModelScope.launch {
            while (isActive) {
                delay(2500L)
                refreshRam()
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        shizukuEngine.unregisterListeners()
    }

    fun onShizukuConnectionAction() {
        val currentStatus = shizukuEngine.refreshStatus()
        when (currentStatus) {
            ShizukuStatus.CONNECTED -> {
                _uiState.update {
                    it.copy(feedbackMessage = "Shizuku conectado e autorizado.")
                }
                refreshApps()
            }
            ShizukuStatus.PERMISSION_REQUIRED -> {
                val requested = shizukuEngine.requestPermission()
                if (!requested) {
                    _uiState.update {
                        it.copy(feedbackMessage = "Não foi possível solicitar permissão ao Shizuku.")
                    }
                }
            }
            ShizukuStatus.NOT_RUNNING -> {
                val opened = shizukuEngine.openShizukuManager(getApplication())
                val msg = if (opened) {
                    "Abrindo Shizuku. Inicie o serviço e volte para o REFHESS V300."
                } else {
                    "Shizuku não detectado. Instale e inicie o app Shizuku primeiro."
                }
                _uiState.update { it.copy(feedbackMessage = msg) }
            }
        }
    }

    fun refreshShizukuState() {
        shizukuEngine.refreshStatus()
    }

    fun refreshRam() {
        val ram = repository.getRamInfo()
        _uiState.update { it.copy(ramInfo = ram) }
    }

    fun refreshApps() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingApps = true) }
            val connected = shizukuEngine.refreshStatus() == ShizukuStatus.CONNECTED
            val loaded = repository.loadInstalledApps(shizukuConnected = connected)
            _uiState.update {
                it.copy(
                    allApps = loaded,
                    isLoadingApps = false
                )
            }
        }
    }

    fun onSearchQueryChange(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun onTabSelected(index: Int) {
        _uiState.update {
            it.copy(
                selectedTab = index,
                batchMode = if (index != 0) false else it.batchMode,
                selectedPackages = if (index != 0) emptySet() else it.selectedPackages
            )
        }
    }

    fun toggleShowSystemApps() {
        _uiState.update { it.copy(showSystemApps = !it.showSystemApps) }
    }

    fun toggleBatchMode() {
        _uiState.update {
            val next = !it.batchMode
            it.copy(
                batchMode = next,
                selectedPackages = if (next) it.selectedPackages else emptySet()
            )
        }
    }

    fun togglePackageSelection(packageName: String) {
        _uiState.update { state ->
            val updated = state.selectedPackages.toMutableSet()
            if (!updated.add(packageName)) {
                updated.remove(packageName)
            }
            state.copy(selectedPackages = updated)
        }
    }

    fun clearSelection() {
        _uiState.update { it.copy(selectedPackages = emptySet()) }
    }

    fun clearFeedback() {
        _uiState.update { it.copy(feedbackMessage = null) }
    }

    suspend fun loadAppIcon(packageName: String): ImageBitmap? {
        return repository.loadAppIcon(packageName)
    }

    fun freezeApp(app: ManagedApp) {
        if (!ensureShizukuReady()) return
        viewModelScope.launch {
            setBusy(app.packageName, true)
            val result = shizukuEngine.freezeApp(app.packageName)
            if (result.success) {
                updateAppInList(app.packageName) { it.copy(isAppFrozen = true) }
                refreshRam()
                _uiState.update {
                    it.copy(feedbackMessage = "${app.appName} congelado e removido da RAM.")
                }
            } else {
                _uiState.update {
                    it.copy(
                        feedbackMessage = "Falha ao congelar ${app.appName}: ${
                            result.stderr.ifBlank { "código ${result.exitCode}" }
                        }"
                    )
                }
            }
            setBusy(app.packageName, false)
        }
    }

    fun unfreezeApp(app: ManagedApp) {
        if (!ensureShizukuReady()) return
        viewModelScope.launch {
            setBusy(app.packageName, true)
            val result = shizukuEngine.unfreezeApp(app.packageName)
            if (result.success) {
                updateAppInList(app.packageName) { it.copy(isAppFrozen = false) }
                _uiState.update {
                    it.copy(feedbackMessage = "${app.appName} descongelado.")
                }
            } else {
                _uiState.update {
                    it.copy(
                        feedbackMessage = "Falha ao descongelar ${app.appName}: ${
                            result.stderr.ifBlank { "código ${result.exitCode}" }
                        }"
                    )
                }
            }
            setBusy(app.packageName, false)
        }
    }

    fun freezeBackground(app: ManagedApp) {
        if (!ensureShizukuReady()) return
        viewModelScope.launch {
            setBusy(app.packageName, true)
            val result = shizukuEngine.freezeBackground(app.packageName)
            if (result.success) {
                repository.markBackgroundRestrictedLocally(app.packageName, true)
                updateAppInList(app.packageName) { it.copy(isBackgroundFrozen = true) }
                refreshRam()
                _uiState.update {
                    it.copy(feedbackMessage = "2º plano bloqueado para ${app.appName}.")
                }
            } else {
                _uiState.update {
                    it.copy(
                        feedbackMessage = "Erro no 2º plano de ${app.appName}: ${
                            result.stderr.ifBlank { "código ${result.exitCode}" }
                        }"
                    )
                }
            }
            setBusy(app.packageName, false)
        }
    }

    fun releaseBackground(app: ManagedApp) {
        if (!ensureShizukuReady()) return
        viewModelScope.launch {
            setBusy(app.packageName, true)
            val result = shizukuEngine.releaseBackground(app.packageName)
            if (result.success) {
                repository.markBackgroundRestrictedLocally(app.packageName, false)
                updateAppInList(app.packageName) { it.copy(isBackgroundFrozen = false) }
                _uiState.update {
                    it.copy(feedbackMessage = "2º plano liberado para ${app.appName}.")
                }
            } else {
                _uiState.update {
                    it.copy(
                        feedbackMessage = "Erro ao liberar 2º plano de ${app.appName}: ${
                            result.stderr.ifBlank { "código ${result.exitCode}" }
                        }"
                    )
                }
            }
            setBusy(app.packageName, false)
        }
    }

    fun restoreApp(app: ManagedApp) {
        if (!ensureShizukuReady()) return
        viewModelScope.launch {
            setBusy(app.packageName, true)
            var enabledOk = true
            var bgOk = true

            if (app.isAppFrozen) {
                enabledOk = shizukuEngine.unfreezeApp(app.packageName).success
            }
            if (app.isBackgroundFrozen) {
                bgOk = shizukuEngine.releaseBackground(app.packageName).success
                if (bgOk) {
                    repository.markBackgroundRestrictedLocally(app.packageName, false)
                }
            }

            updateAppInList(app.packageName) {
                it.copy(
                    isAppFrozen = if (enabledOk) false else it.isAppFrozen,
                    isBackgroundFrozen = if (bgOk) false else it.isBackgroundFrozen
                )
            }

            val message = if (enabledOk && bgOk) {
                "${app.appName} totalmente restaurado."
            } else {
                "Restauração parcial de ${app.appName}. Verifique as permissões do Shizuku."
            }
            _uiState.update { it.copy(feedbackMessage = message) }
            setBusy(app.packageName, false)
        }
    }

    fun freezeSelectedApps() {
        val targets = _uiState.value.selectedPackages.toList()
        if (targets.isEmpty() || !ensureShizukuReady()) return
        viewModelScope.launch {
            _uiState.update { it.copy(isBatchBusy = true) }
            var successCount = 0
            for (pkg in targets) {
                if (shizukuEngine.freezeApp(pkg).success) {
                    successCount++
                    updateAppInList(pkg) { it.copy(isAppFrozen = true) }
                }
            }
            refreshRam()
            _uiState.update {
                it.copy(
                    isBatchBusy = false,
                    batchMode = false,
                    selectedPackages = emptySet(),
                    feedbackMessage = "$successCount de ${targets.size} apps congelados em lote."
                )
            }
        }
    }

    fun freezeSelectedBackground() {
        val targets = _uiState.value.selectedPackages.toList()
        if (targets.isEmpty() || !ensureShizukuReady()) return
        viewModelScope.launch {
            _uiState.update { it.copy(isBatchBusy = true) }
            var successCount = 0
            for (pkg in targets) {
                if (shizukuEngine.freezeBackground(pkg).success) {
                    successCount++
                    repository.markBackgroundRestrictedLocally(pkg, true)
                    updateAppInList(pkg) { it.copy(isBackgroundFrozen = true) }
                }
            }
            refreshRam()
            _uiState.update {
                it.copy(
                    isBatchBusy = false,
                    batchMode = false,
                    selectedPackages = emptySet(),
                    feedbackMessage = "2º plano bloqueado em $successCount de ${targets.size} apps."
                )
            }
        }
    }

    fun unfreezeAll() {
        val restrictedApps = _uiState.value.allApps.filter { it.isAnyRestrictionActive }
        if (restrictedApps.isEmpty() || !ensureShizukuReady()) return
        viewModelScope.launch {
            _uiState.update { it.copy(isBatchBusy = true) }
            var restoredCount = 0
            for (app in restrictedApps) {
                var ok = true
                if (app.isAppFrozen) {
                    ok = shizukuEngine.unfreezeApp(app.packageName).success && ok
                }
                if (app.isBackgroundFrozen) {
                    val bgOk = shizukuEngine.releaseBackground(app.packageName).success
                    if (bgOk) {
                        repository.markBackgroundRestrictedLocally(app.packageName, false)
                    }
                    ok = bgOk && ok
                }
                if (ok) {
                    restoredCount++
                    updateAppInList(app.packageName) {
                        it.copy(isAppFrozen = false, isBackgroundFrozen = false)
                    }
                }
            }
            refreshRam()
            _uiState.update {
                it.copy(
                    isBatchBusy = false,
                    feedbackMessage = "$restoredCount de ${restrictedApps.size} aplicativos descongelados/restaurados."
                )
            }
        }
    }

    private fun ensureShizukuReady(): Boolean {
        val status = shizukuEngine.refreshStatus()
        if (status == ShizukuStatus.CONNECTED) return true
        onShizukuConnectionAction()
        return false
    }

    private fun setBusy(packageName: String, busy: Boolean) {
        _uiState.update { state ->
            val updated = state.busyPackages.toMutableSet()
            if (busy) updated.add(packageName) else updated.remove(packageName)
            state.copy(busyPackages = updated)
        }
    }

    private fun updateAppInList(
        packageName: String,
        transform: (ManagedApp) -> ManagedApp
    ) {
        _uiState.update { state ->
            val updatedList = state.allApps.map { app ->
                if (app.packageName == packageName) transform(app) else app
            }
            state.copy(allApps = updatedList)
        }
    }
}
