package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.security.SecurityBlockedScreen
import com.example.security.SecurityGuard
import com.example.ui.RefhessScreen
import com.example.ui.RefhessViewModel
import com.example.ui.theme.RefhessV300Theme

class MainActivity : ComponentActivity() {

    private var activeViewModel: RefhessViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )

        val securityResult = SecurityGuard.verifyIntegrity(this)

        setContent {
            RefhessV300Theme {
                if (securityResult.isTampered) {
                    SecurityBlockedScreen(packageName = securityResult.currentPackageName)
                } else {
                    val vm: RefhessViewModel = viewModel()
                    activeViewModel = vm
                    RefhessScreen(viewModel = vm)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        activeViewModel?.let { vm ->
            vm.refreshShizukuState()
            vm.refreshRam()
        }
    }
}
