package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val RefhessDarkColorScheme = darkColorScheme(
    primary = IceCyan,
    onPrimary = MidnightBackground,
    primaryContainer = NeonBlueDeep,
    onPrimaryContainer = TextPrimary,
    secondary = NeonBlue,
    onSecondary = TextPrimary,
    secondaryContainer = CardSurfaceAlt,
    onSecondaryContainer = IceCyan,
    tertiary = StatusConnected,
    onTertiary = MidnightBackground,
    background = MidnightBackground,
    onBackground = TextPrimary,
    surface = CardSurface,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = BorderSubtle,
    error = StatusDisconnected,
    onError = TextPrimary
)

private val RefhessShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp)
)

@Composable
fun RefhessV300Theme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = RefhessDarkColorScheme,
        typography = Typography,
        shapes = RefhessShapes,
        content = content
    )
}
