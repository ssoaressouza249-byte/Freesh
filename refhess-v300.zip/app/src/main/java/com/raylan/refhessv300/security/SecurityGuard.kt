package com.example.security

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GppBad
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.SecurityTamperRed

data class SecurityCheckResult(
    val isTampered: Boolean,
    val currentPackageName: String,
    val currentAppName: String
)

object SecurityGuard {
    const val EXPECTED_PACKAGE_NAME = "com.raylan.refhessv300"
    const val EXPECTED_APP_NAME = "REFHESS V300"

    /**
     * Verifies ONLY the package name and app label so debug certificates
     * (including CI/GitHub Actions builds) work normally while blocking
     * APK repackaging/renaming via MT Manager, NP Manager, or APK Editor.
     */
    fun verifyIntegrity(context: Context): SecurityCheckResult {
        val currentPackage = runCatching { context.packageName }.getOrDefault("")
        val currentLabel = runCatching {
            context.applicationInfo.loadLabel(context.packageManager).toString()
        }.getOrDefault("")

        val packageMatches = currentPackage == EXPECTED_PACKAGE_NAME
        val labelMatches = currentLabel == EXPECTED_APP_NAME

        return SecurityCheckResult(
            isTampered = !(packageMatches && labelMatches),
            currentPackageName = currentPackage,
            currentAppName = currentLabel
        )
    }
}

@Composable
fun SecurityBlockedScreen(
    packageName: String
) {
    val context = LocalContext.current

    // Block back button permanently on tampered builds
    BackHandler(enabled = true) {}

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(SecurityTamperRed)
            .systemBarsPadding()
            .padding(24.dp)
            .testTag("security_blocked_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Filled.GppBad,
                contentDescription = stringResource(R.string.security_alert_message),
                tint = Color.White,
                modifier = Modifier.size(88.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = stringResource(R.string.security_alert_message),
                color = Color.White,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp,
                    lineHeight = 28.sp
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(36.dp))

            Button(
                onClick = {
                    runCatching {
                        val intent = Intent(
                            Intent.ACTION_DELETE,
                            Uri.parse("package:$packageName")
                        ).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = SecurityTamperRed
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .testTag("security_uninstall_button")
            ) {
                Text(
                    text = stringResource(R.string.security_uninstall_now),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    letterSpacing = 1.2.sp
                )
            }
        }
    }
}
