package com.example.data

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.example.shizuku.ShizukuEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AppRepository(
    private val context: Context,
    private val shizukuEngine: ShizukuEngine
) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val iconCache = LruCache<String, ImageBitmap>(180)

    private val excludedPackages: Set<String> = setOf(
        "com.raylan.refhessv300",
        context.packageName,
        "com.android.systemui",
        "com.android.settings",
        "moe.shizuku.privileged.api"
    )

    fun getRamInfo(): RamInfo {
        return runCatching {
            val activityManager =
                context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
                    ?: return@runCatching RamInfo()
            val memoryInfo = ActivityManager.MemoryInfo()
            activityManager.getMemoryInfo(memoryInfo)
            val total = memoryInfo.totalMem.coerceAtLeast(1L)
            val available = memoryInfo.availMem.coerceIn(0L, total)
            val used = (total - available).coerceAtLeast(0L)
            val fraction = (used.toDouble() / total.toDouble()).toFloat().coerceIn(0f, 1f)
            RamInfo(
                totalBytes = total,
                availableBytes = available,
                usedBytes = used,
                usedFraction = fraction,
                isLowMemory = memoryInfo.lowMemory
            )
        }.getOrDefault(RamInfo())
    }

    suspend fun loadInstalledApps(shizukuConnected: Boolean): List<ManagedApp> =
        withContext(Dispatchers.IO) {
            val pm = context.packageManager

            val shizukuDisabledSet = if (shizukuConnected) {
                runCatching { shizukuEngine.queryDisabledPackages() }.getOrDefault(emptySet())
            } else {
                emptySet()
            }

            val bgRestrictedSet = if (shizukuConnected) {
                val queried = runCatching {
                    shizukuEngine.queryBackgroundRestrictedPackages()
                }.getOrDefault(emptySet())
                saveCachedBgRestricted(queried)
                queried
            } else {
                getCachedBgRestricted()
            }

            val appInfos: List<ApplicationInfo> = runCatching {
                val flags = PackageManager.MATCH_DISABLED_COMPONENTS or
                    PackageManager.MATCH_UNINSTALLED_PACKAGES or
                    PackageManager.GET_META_DATA
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(flags.toLong()))
                } else {
                    @Suppress("DEPRECATION")
                    pm.getInstalledApplications(flags)
                }
            }.getOrElse {
                runCatching {
                    @Suppress("DEPRECATION")
                    pm.getInstalledApplications(0)
                }.getOrDefault(emptyList())
            }

            appInfos
                .asSequence()
                .filter { info -> info.packageName !in excludedPackages }
                .mapNotNull { info ->
                    runCatching {
                        val pkg = info.packageName
                        val label = info.loadLabel(pm).toString().ifBlank { pkg }
                        val isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                            (info.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0

                        val enabledState = runCatching {
                            pm.getApplicationEnabledSetting(pkg)
                        }.getOrDefault(PackageManager.COMPONENT_ENABLED_STATE_DEFAULT)

                        val isDisabledByPm = !info.enabled ||
                            enabledState == PackageManager.COMPONENT_ENABLED_STATE_DISABLED ||
                            enabledState == PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER ||
                            enabledState == PackageManager.COMPONENT_ENABLED_STATE_DISABLED_UNTIL_USED

                        val isAppFrozen = isDisabledByPm || pkg in shizukuDisabledSet
                        val isBackgroundFrozen = pkg in bgRestrictedSet

                        val versionName = runCatching {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                pm.getPackageInfo(
                                    pkg,
                                    PackageManager.PackageInfoFlags.of(0L)
                                ).versionName
                            } else {
                                @Suppress("DEPRECATION")
                                pm.getPackageInfo(pkg, 0).versionName
                            }
                        }.getOrNull()

                        ManagedApp(
                            packageName = pkg,
                            appName = label,
                            isSystemApp = isSystem,
                            isAppFrozen = isAppFrozen,
                            isBackgroundFrozen = isBackgroundFrozen,
                            versionName = versionName
                        )
                    }.getOrNull()
                }
                .sortedWith(
                    compareByDescending<ManagedApp> { it.isAnyRestrictionActive }
                        .thenBy { it.appName.lowercase() }
                )
                .toList()
        }

    suspend fun loadAppIcon(packageName: String): ImageBitmap? = withContext(Dispatchers.IO) {
        iconCache.get(packageName)?.let { return@withContext it }
        runCatching {
            val drawable = context.packageManager.getApplicationIcon(packageName)
            val bitmap = drawableToBitmap(drawable, sizePx = 96)
            val imageBitmap = bitmap.asImageBitmap()
            iconCache.put(packageName, imageBitmap)
            imageBitmap
        }.getOrNull()
    }

    fun markBackgroundRestrictedLocally(packageName: String, restricted: Boolean) {
        val current = getCachedBgRestricted().toMutableSet()
        if (restricted) {
            current.add(packageName)
        } else {
            current.remove(packageName)
        }
        saveCachedBgRestricted(current)
    }

    private fun getCachedBgRestricted(): Set<String> {
        return runCatching {
            prefs.getStringSet(KEY_BG_RESTRICTED, emptySet()) ?: emptySet()
        }.getOrDefault(emptySet())
    }

    private fun saveCachedBgRestricted(packages: Set<String>) {
        runCatching {
            prefs.edit().putStringSet(KEY_BG_RESTRICTED, packages.toSet()).apply()
        }
    }

    private fun drawableToBitmap(drawable: Drawable, sizePx: Int): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            val src = drawable.bitmap
            return if (src.width > sizePx || src.height > sizePx) {
                Bitmap.createScaledBitmap(src, sizePx, sizePx, true)
            } else {
                src
            }
        }
        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }

    companion object {
        private const val PREFS_NAME = "refhess_v300_state"
        private const val KEY_BG_RESTRICTED = "bg_restricted_packages"
    }
}
