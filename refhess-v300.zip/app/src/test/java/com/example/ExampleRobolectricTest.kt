package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.security.SecurityGuard
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context matches REFHESS V300`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("REFHESS V300", appName)
    }

    @Test
    fun `security guard passes for authentic package and label`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val result = SecurityGuard.verifyIntegrity(context)
        assertEquals("com.raylan.refhessv300", result.currentPackageName)
        assertEquals("REFHESS V300", result.currentAppName)
        assertFalse(result.isTampered)
    }
}
